package com.udacity.project4.locationreminders.data.local

import android.os.Build
import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.MediumTest
import com.udacity.project4.locationreminders.data.ReminderDataSource
import com.udacity.project4.locationreminders.data.dto.ReminderDTO
import com.udacity.project4.locationreminders.data.dto.Result
import junit.framework.Assert
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.runBlockingTest
import org.hamcrest.CoreMatchers.`is`
import org.hamcrest.CoreMatchers.instanceOf
import org.hamcrest.MatcherAssert.assertThat
import org.junit.After
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config

@ExperimentalCoroutinesApi
@RunWith(AndroidJUnit4::class)
//Medium Test to test the repository
@MediumTest
@Config(sdk = intArrayOf(Build.VERSION_CODES.P))
class RemindersLocalRepositoryTest(var reminders :MutableList<ReminderDTO>) : ReminderDataSource {

    //    TODO: Add testing implementation to the RemindersLocalRepository.kt
    private var shouldReturnError = false
    fun setReturnError(value:Boolean){
        shouldReturnError=value
    }

    override suspend fun getReminders(): Result<List<ReminderDTO>> {
        if (shouldReturnError) {
            return Result.Error("Reminder not found!")
        }
        return Result.Success(reminders)

    }

    override suspend fun saveReminder(reminder: ReminderDTO) {
        //TODO("save the reminder")
        reminders.add(reminder)
    }

    override suspend fun getReminder(id: String): Result<ReminderDTO> {
        //TODO("return the reminder with the id")
        if (shouldReturnError) {
            return Result.Error("Reminder not found!")
        }

        val remider:ReminderDTO = reminders.find { it.id == id  }!!
        return Result.Success(remider)

    }

    @Test
    fun getReminder_notExistingId_shouldReturnError()= runBlockingTest {
        //Arrange should return error
        shouldReturnError = true
        //when  passing not existing id
        val res:Result.Error = getReminder("xys") as Result.Error
        //then it should return error
        val exp = Result.Error("Reminder not found!")
        Assert.assertEquals(res.message, exp.message)
    }
    override suspend fun deleteAllReminders() {
        //TODO("delete all the reminders")
        reminders.clear()
    }
}